#!/bin/bash
rm -r AROS.HUNK
rm -r AROS.PROGRAMS
rm -r 3rd_party
rm -r cf_card

